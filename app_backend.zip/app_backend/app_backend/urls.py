"""
URL configuration for app_backend project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import path
from emailAuth.views import (
    SendEmailVerificationLinkView,
    VerifyEmailView,
    SendPasswordResetLinkView,
    ResetPasswordConfirmView,
    EmailVerificationReminderView,
    TTSConversionView,
    VoiceCloneView,
    VoiceListView,
    TopUpBalanceView,
    UserHistoryListView,
    PaymentInitiateView,
    PaymentWebhookView,
    RegisterView,
    LoginView,
    ResetPasswordView,
    GoogleAuthView,
    BalanceView,
    UserHistoryDetailView,
    PaymentDetailsView,
    SampleVoicesView,
    ResetPasswordConfirmApiView
)
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
 


urlpatterns = [
    path('adminfourthbigroup/', admin.site.urls),
    # path('auth/', include('emailAuth.urls')),



    path('auth/send-email-verification/', SendEmailVerificationLinkView.as_view(), name='send-email-verification'),
    path('auth/verify-email/', VerifyEmailView.as_view(), name='verify-email'),
    path('auth/send-password-reset/', SendPasswordResetLinkView.as_view(), name='send-password-reset'),
    path('auth/reset-password-confirm/', ResetPasswordConfirmView.as_view(), name='reset-password-confirm'),
    path('email/verify/', EmailVerificationReminderView.as_view(), name='email-verify'),
    path('tts/', TTSConversionView.as_view(), name='tts-conversion'),
    path('voices/clone/', VoiceCloneView.as_view(), name='voice-clone'),
    path('voices/', VoiceListView.as_view(), name='voice-list'),
    path('balance/topup/', TopUpBalanceView.as_view(), name='balance-topup'),
    path('payments/flutterwave/details/', PaymentDetailsView.as_view(), name='flutterwave-details'),
    path('payments/btcpay/details/', PaymentDetailsView.as_view(), name='btcpay-details'),
    path('payments/coingate/details/', PaymentDetailsView.as_view(), name='coingate-details'),
    path('history/', UserHistoryListView.as_view(), name='user-history'),
    path('payments/initiate/', PaymentInitiateView.as_view(), name='payment-initiate'),
    path('payments/webhook/', PaymentWebhookView.as_view(), name='payment-webhook'),
    path('auth/register/', RegisterView.as_view(), name='auth-register'),
    path('auth/login/', LoginView.as_view(), name='auth-login'),
    path('auth/reset-password/', ResetPasswordView.as_view(), name='auth-reset-password'),
    path('auth/google/', GoogleAuthView.as_view(), name='auth-google'),
    path('user/balance/', BalanceView.as_view(), name='user-balance'),
    path('history/<int:pk>/', UserHistoryDetailView.as_view(), name='history-detail'),
    path('elevenlabs/voices/', SampleVoicesView.as_view(), name='elevenlabs-voices'),
    path('api/reset-password/<str:uidb64>/<str:token>/', ResetPasswordConfirmApiView.as_view(), name='reset-password-confirm-api'),

    


]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)


handler404 = 'emailAuth.views.custom_404_view'
